<?php

use PHPUnit\Framework\TestCase;
use GuzzleHttp\Client;

class RegisterTest extends TestCase
{
    private $client;

    protected function setUp(): void
    {
        $this->client = new Client(['base_uri' => 'http://localhost/Iceworld/']);
    }

    public function testSuccessfulRegistration()
    {
        $response = $this->client->post('register.php', [
            'form_params' => [
                'name' => 'Test User',
                'email' => 'uniqueuser@example.com', // Ensure this email is not in your database
                'number' => '1234567890', // Ensure this number is not in your database
                'pass' => 'password123',
                'cpass' => 'password123',
                'submit' => 'register now'
            ]
        ]);

        // Check for successful redirection to home.php
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('Location: home.php', (string) $response->getBody());
    }

    public function testRegistrationWithExistingEmailOrNumber()
    {
        $response = $this->client->post('register.php', [
            'form_params' => [
                'name' => 'Test User',
                'email' => 'existinguser@example.com', // Use an existing email in your database
                'number' => '1234567890', // Use an existing number in your database
                'pass' => 'password123',
                'cpass' => 'password123',
                'submit' => 'register now'
            ]
        ]);

        // Check for the error message
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('email or number already exists!', (string) $response->getBody());
    }

    public function testRegistrationWithMismatchedPasswords()
    {
        $response = $this->client->post('register.php', [
            'form_params' => [
                'name' => 'Test User',
                'email' => 'anotheruniqueuser@example.com', // Ensure this email is not in your database
                'number' => '0987654321', // Ensure this number is not in your database
                'pass' => 'password123',
                'cpass' => 'password321',
                'submit' => 'register now'
            ]
        ]);

        // Check for the error message
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('confirm password not matched!', (string) $response->getBody());
    }
}
