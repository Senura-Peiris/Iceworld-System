<?php

use PHPUnit\Framework\TestCase;
use GuzzleHttp\Client;

class LoginTest extends TestCase
{
    private $client;

    protected function setUp(): void
    {
        $this->client = new Client(['base_uri' => 'http://localhost/Iceworld/']);
    }

    public function testSuccessfulLogin()
    {
        $response = $this->client->post('login.php', [
            'form_params' => [
                'email' => 'validuser@example.com', // Replace with a valid email in your database
                'pass' => 'validpassword', // Replace with the corresponding password
                'submit' => 'login now'
            ]
        ]);

        // Check for successful redirection to home.php
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('Location: home.php', (string) $response->getBody());
    }

    public function testUnsuccessfulLogin()
    {
        $response = $this->client->post('login.php', [
            'form_params' => [
                'email' => 'invaliduser@example.com', // Use an invalid email
                'pass' => 'invalidpassword', // Use an invalid password
                'submit' => 'login now'
            ]
        ]);

        // Check for the error message
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('incorrect username or password!', (string) $response->getBody());
    }
}
