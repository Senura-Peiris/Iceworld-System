<footer class="footer">

   <section class="grid">

      <div class="box">
         <img src="images/email-icon.png" alt="">
         <h3>Our Email</h3>
        <a href="mailto:senurapieris@gmail.com">senurapieris@gmail.com</a>
         <a href="mailto:senurapeiris895@gmail.com">senurapeirsi895@gmail.com</a>
      </div>

      <div class="box">
         <img src="images/clock-icon.png" alt="">
         <h3>Opening Hours</h3>
         <p>7:00am to 6:00pm</p>
         <p>Daily ,Closed Special Holidays</p>
         
      </div>

      <div class="box">
         <img src="images/map-icon.png" alt="">
         <h3>Our Address</h3>
         <a href="#">No.5,Kohuwala Street, Nugegoda</a>
      </div>

      <div class="box">
         <img src="images/phone-icon.png" alt="">
         <h3>Our Number</h3>
         <a href="tel:1234567890">071 876 3405</a>
         <a href="tel:1112223333">077 789 0034</a>
      </div>

   </section>

   <div class="credit">&copy; <?= date('Y'); ?> by <span>Mr. Senura Peiris </span>| 𝐼𝒞𝐸 𝒲𝒪𝑅𝐿𝒟  </div>

</footer>
<!--
<div class="loader">
   <img src="images/loader.gif" alt="">
</div>-->