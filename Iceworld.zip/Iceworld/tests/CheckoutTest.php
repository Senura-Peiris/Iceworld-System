<?php

use PHPUnit\Framework\TestCase;
use GuzzleHttp\Client;

class CheckoutTest extends TestCase
{
    private $client;

    protected function setUp(): void
    {
        $this->client = new Client(['base_uri' => 'http://localhost/Iceworld/']);
    }

    public function testOrderPlacementWithEmptyCart()
    {
        // Simulate a logged-in user
        $cookieJar = new \GuzzleHttp\Cookie\CookieJar();
        $response = $this->client->post('login.php', [
            'form_params' => [
                'email' => 'user@example.com',
                'pass' => 'password',
                'submit' => 'login now'
            ],
            'cookies' => $cookieJar
        ]);

        // Place order with an empty cart
        $response = $this->client->post('checkout.php', [
            'form_params' => [
                'submit' => 'place order'
            ],
            'cookies' => $cookieJar
        ]);

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('your cart is empty', (string) $response->getBody());
    }

    public function testOrderPlacementWithNoAddress()
    {
        // Simulate a logged-in user
        $cookieJar = new \GuzzleHttp\Cookie\CookieJar();
        $response = $this->client->post('login.php', [
            'form_params' => [
                'email' => 'user@example.com',
                'pass' => 'password',
                'submit' => 'login now'
            ],
            'cookies' => $cookieJar
        ]);

        // Place order with no address
        $response = $this->client->post('checkout.php', [
            'form_params' => [
                'total_products' => 'Product 1 (100 x 1)',
                'total_price' => '100',
                'method' => 'cash on delivery',
                'submit' => 'place order'
            ],
            'cookies' => $cookieJar
        ]);

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('please add your address', (string) $response->getBody());
    }

    public function testSuccessfulOrderPlacement()
    {
        // Simulate a logged-in user
        $cookieJar = new \GuzzleHttp\Cookie\CookieJar();
        $response = $this->client->post('login.php', [
            'form_params' => [
                'email' => 'user@example.com',
                'pass' => 'password',
                'submit' => 'login now'
            ],
            'cookies' => $cookieJar
        ]);

        // Place order successfully
        $response = $this->client->post('checkout.php', [
            'form_params' => [
                'total_products' => 'Product 1 (100 x 1)',
                'total_price' => '100',
                'name' => 'Test User',
                'number' => '1234567890',
                'email' => 'user@example.com',
                'address' => '123 Test Address',
                'method' => 'cash on delivery',
                'submit' => 'place order'
            ],
            'cookies' => $cookieJar
        ]);

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('order placed successfully!', (string) $response->getBody());
    }
}
