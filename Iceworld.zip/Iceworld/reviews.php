<?php

include 'components/connect.php';

session_start();

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
} else {
    $user_id = '';
}

if (isset($_POST['send'])) {

    $name = $_POST['name'];
    $name = filter_var($name, FILTER_SANITIZE_STRING);
    $review = $_POST['review'];
    $review = filter_var($review, FILTER_SANITIZE_STRING);

    // Check if the file input is set and contains no errors
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $image = $_FILES['image']['name'];
        $image_size = $_FILES['image']['size'];
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $image_folder = './uploaded_img/' . $image;

        $select_review = $conn->prepare("SELECT * FROM `reviews` WHERE name = ? AND image = ? AND review = ?");
        $select_review->execute([$name, $image, $review]);

        if ($select_review->rowCount() > 0) {
            $message[] = 'Already Reviewed!';
        } else {
            if ($image_size > 0 && $image_size <= 2000000) { // Check if the image size is less than 2MB
                if (move_uploaded_file($image_tmp_name, $image_folder)) {
                    $insert_message = $conn->prepare("INSERT INTO `reviews` (name, review, image) VALUES (?, ?, ?)");
                    $insert_message->execute([$name, $review, $image]);
                    $message[] = 'Reviewed successfully!';
                } else {
                    $message[] = 'Failed to upload image!';
                }
            } else {
                $message[] = 'Image size is too large!';
            }
        }
    } else {
        $message[] = 'Please select an image!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Page</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/styles1.css">

</head>
<body>
   
<!-- header section starts  -->
<?php include 'components/user_header.php'; ?>
<!-- header section ends -->

<div class="heading">
    <h3>Customers Reviews</h3>
    <p><a href="about.php">About</a> <span> / Reviews</span></p>
</div>

<!---Customer review page section start here--->
<section class="contact">

    <div class="row">

        <div class="image">
            <img src="image/reviews.jfif" alt="">
        </div>

        <form action="" method="post" enctype="multipart/form-data">
            <h3>Your Review</h3>
            <input type="text" name="name" maxlength="50" class="box" placeholder="Your Name" required>
            <input type="file" name="image" required class="box" accept="image/jpg, image/jpeg, image/png">
            <textarea name="review" class="box" required placeholder="Your Review" maxlength="500" cols="30" rows="10"></textarea>
            <input type="submit" value="send review" name="send" class="btn">
        </form>

    </div>

</section>

<!-- contact section ends -->

<!-- footer section starts  -->
<?php include 'components/footer.php'; ?>
<!-- footer section ends -->

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>
