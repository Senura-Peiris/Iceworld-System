<?php

use PHPUnit\Framework\TestCase;
use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;

class CartTest extends TestCase
{
    private $client;
    private $cookieJar;

    protected function setUp(): void
    {
        $this->client = new Client(['base_uri' => 'http://localhost/Iceworld/']);
        $this->cookieJar = new CookieJar();
    }

    public function testDeleteSingleItemFromCart()
    {
        // Add item to cart
        $response = $this->client->post('cart.php', [
            'form_params' => [
                'cart_id' => 1, // Assume a cart item with id 1 exists
                'delete' => true,
            ],
            'cookies' => $this->cookieJar
        ]);

        $body = (string) $response->getBody();
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('cart item deleted!', $body);
    }

    public function testDeleteAllItemsFromCart()
    {
        // Add multiple items to cart
        $response = $this->client->post('cart.php', [
            'form_params' => [
                'delete_all' => true,
            ],
            'cookies' => $this->cookieJar
        ]);

        $body = (string) $response->getBody();
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('deleted all from cart!', $body);
    }

    public function testUpdateCartItemQuantity()
    {
        // Update item quantity in cart
        $response = $this->client->post('cart.php', [
            'form_params' => [
                'cart_id' => 1, // Assume a cart item with id 1 exists
                'qty' => 3,
                'update_qty' => true,
            ],
            'cookies' => $this->cookieJar
        ]);

        $body = (string) $response->getBody();
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('cart quantity updated', $body);
    }
}
