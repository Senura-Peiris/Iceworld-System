<?php

use PHPUnit\Framework\TestCase;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\MultipartStream;

class ReviewTest extends TestCase
{
    private $client;

    protected function setUp(): void
    {
        $this->client = new Client(['base_uri' => 'http://localhost/Iceworld/']);
    }

    public function testSuccessfulReviewSubmission()
    {
        $multipart = new MultipartStream([
            [
                'name'     => 'name',
                'contents' => 'Test User'
            ],
            [
                'name'     => 'review',
                'contents' => 'This is a test review.'
            ],
            [
                'name'     => 'image',
                'contents' => fopen(__DIR__ . '/test_image.jpg', 'r'),
                'filename' => 'test_image.jpg'
            ],
            [
                'name'     => 'send',
                'contents' => 'send review'
            ]
        ]);

        $response = $this->client->post('contact.php', [
            'headers' => [
                'Content-Type' => 'multipart/form-data; boundary=' . $multipart->getBoundary()
            ],
            'body' => $multipart
        ]);

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('Reviewed successfully!', (string) $response->getBody());
    }

    public function testReviewWithExistingData()
    {
        $multipart = new MultipartStream([
            [
                'name'     => 'name',
                'contents' => 'Existing User'
            ],
            [
                'name'     => 'review',
                'contents' => 'This is an existing review.'
            ],
            [
                'name'     => 'image',
                'contents' => fopen(__DIR__ . '/test_image.jpg', 'r'),
                'filename' => 'test_image.jpg'
            ],
            [
                'name'     => 'send',
                'contents' => 'send review'
            ]
        ]);

        $response = $this->client->post('contact.php', [
            'headers' => [
                'Content-Type' => 'multipart/form-data; boundary=' . $multipart->getBoundary()
            ],
            'body' => $multipart
        ]);

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('Already Reviewed!', (string) $response->getBody());
    }

    public function testReviewSubmissionWithLargeImage()
    {
        $multipart = new MultipartStream([
            [
                'name'     => 'name',
                'contents' => 'Test User'
            ],
            [
                'name'     => 'review',
                'contents' => 'This is a test review.'
            ],
            [
                'name'     => 'image',
                'contents' => fopen(__DIR__ . '/large_test_image.jpg', 'r'),
                'filename' => 'large_test_image.jpg'
            ],
            [
                'name'     => 'send',
                'contents' => 'send review'
            ]
        ]);

        $response = $this->client->post('contact.php', [
            'headers' => [
                'Content-Type' => 'multipart/form-data; boundary=' . $multipart->getBoundary()
            ],
            'body' => $multipart
        ]);

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('Image size is too large!', (string) $response->getBody());
    }

    public function testReviewSubmissionWithoutImage()
    {
        $multipart = new MultipartStream([
            [
                'name'     => 'name',
                'contents' => 'Test User'
            ],
            [
                'name'     => 'review',
                'contents' => 'This is a test review.'
            ],
            [
                'name'     => 'send',
                'contents' => 'send review'
            ]
        ]);

        $response = $this->client->post('contact.php', [
            'headers' => [
                'Content-Type' => 'multipart/form-data; boundary=' . $multipart->getBoundary()
            ],
            'body' => $multipart
        ]);

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('Please select an image!', (string) $response->getBody());
    }
}
