<?php

use PHPUnit\Framework\TestCase;
use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;

class ContactTest extends TestCase
{
    private $client;

    protected function setUp(): void
    {
        $this->client = new Client(['base_uri' => 'http://localhost/Iceworld/']);
    }

    public function testContactFormSubmissionWithValidData()
    {
        $cookieJar = new CookieJar();
        $response = $this->client->post('contact.php', [
            'form_params' => [
                'name' => 'Test User',
                'number' => '1234567890',
                'email' => 'testuser@example.com',
                'msg' => 'This is a test message.',
                'send' => 'send message'
            ],
            'cookies' => $cookieJar
        ]);

        $body = (string) $response->getBody();
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('sent message successfully!', $body);
    }

    public function testContactFormSubmissionWithDuplicateData()
    {
        $cookieJar = new CookieJar();
        
        // First submission
        $this->client->post('contact.php', [
            'form_params' => [
                'name' => 'Duplicate User',
                'number' => '0987654321',
                'email' => 'duplicateuser@example.com',
                'msg' => 'This is a duplicate test message.',
                'send' => 'send message'
            ],
            'cookies' => $cookieJar
        ]);

        // Duplicate submission
        $response = $this->client->post('contact.php', [
            'form_params' => [
                'name' => 'Duplicate User',
                'number' => '0987654321',
                'email' => 'duplicateuser@example.com',
                'msg' => 'This is a duplicate test message.',
                'send' => 'send message'
            ],
            'cookies' => $cookieJar
        ]);

        $body = (string) $response->getBody();
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('already sent message!', $body);
    }
}
