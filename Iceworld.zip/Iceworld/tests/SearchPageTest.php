<?php
use PHPUnit\Framework\TestCase;

class SearchPageTest extends TestCase
{
    protected $conn;

    protected function setUp(): void
    {
        // Mock database connection
        $this->conn = $this->createMock(PDO::class);

        // Mock session
        $_SESSION = [];
    }

    public function testSearchPageLoadsSuccessfully()
    {
        // Mock the prepare method to return a PDOStatement mock
        $stmt = $this->createMock(PDOStatement::class);
        $this->conn->method('prepare')->willReturn($stmt);

        // Mock the execute method
        $stmt->method('execute')->willReturn(true);

        // Mock the rowCount method
        $stmt->method('rowCount')->willReturn(0);

        // Include the search.php script
        ob_start();
        include 'path/to/search.php';
        $output = ob_get_clean();

        // Assert that the page loads and contains the search form
        $this->assertStringContainsString('<section class="search-form">', $output);
    }

    public function testSearchPageDisplaysSearchResults()
    {
        // Simulate form input for search
        $_POST['search_box'] = 'Blueberry';
        $_POST['search_btn'] = true;

        // Mock the prepare method to return a PDOStatement mock
        $stmt = $this->createMock(PDOStatement::class);
        $this->conn->method('prepare')->willReturn($stmt);

        // Mock the execute method
        $stmt->method('execute')->willReturn(true);

        // Mock the rowCount method to return more than 0
        $stmt->method('rowCount')->willReturn(1);

        // Mock the fetch method to return a sample product
        $stmt->method('fetch')->willReturn([
            'id' => 1,
            'name' => 'Vanilla Milkshake',
            'price' => 5.99,
            'image' => 'vanilla.jpg',
            'category' => 'vanilla'
        ]);

        // Include the search.php script
        ob_start();
        include 'path/to/search.php';
        $output = ob_get_clean();

        // Assert that the page displays the search result
        $this->assertStringContainsString('Vanilla Milkshake', $output);
        $this->assertStringContainsString('$5.99', $output);
        $this->assertStringContainsString('vanilla.jpg', $output);
    }

    public function testSearchPageHandlesNoSearchResults()
    {
        // Simulate form input for search
        $_POST['search_box'] = 'Nonexistent Product';
        $_POST['search_btn'] = true;

        // Mock the prepare method to return a PDOStatement mock
        $stmt = $this->createMock(PDOStatement::class);
        $this->conn->method('prepare')->willReturn($stmt);

        // Mock the execute method
        $stmt->method('execute')->willReturn(true);

        // Mock the rowCount method to return 0
        $stmt->method('rowCount')->willReturn(0);

        // Include the search.php script
        ob_start();
        include 'path/to/search.php';
        $output = ob_get_clean();

        // Assert that the page handles no search results
        $this->assertStringContainsString('<p class="empty">no products added yet!</p>', $output);
    }
}
?>
