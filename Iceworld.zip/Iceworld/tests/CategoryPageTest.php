<?php
use PHPUnit\Framework\TestCase;

class CategoryPageTest extends TestCase
{
    protected $conn;

    protected function setUp(): void
    {
        // Mock database connection
        $this->conn = $this->createMock(PDO::class);

        // Mock session
        $_SESSION = [];
    }

    public function testCategoryPageLoadsSuccessfully()
    {
        // Simulate a category being passed in the GET request
        $_GET['category'] = 'Ice Cream';

        // Mock the prepare method to return a PDOStatement mock
        $stmt = $this->createMock(PDOStatement::class);
        $this->conn->method('prepare')->willReturn($stmt);

        // Mock the execute method
        $stmt->method('execute')->willReturn(true);

        // Mock the rowCount method
        $stmt->method('rowCount')->willReturn(0);

        // Include the category.php script
        ob_start();
        include 'path/to/category.php';
        $output = ob_get_clean();

        // Assert that the page loads and contains the title
        $this->assertStringContainsString('<h1 class="title">Ice Cream categories</h1>', $output);
    }

    public function testCategoryPageDisplaysProducts()
    {
        // Simulate a category being passed in the GET request
        $_GET['category'] = 'Ice Cream';

        // Mock the prepare method to return a PDOStatement mock
        $stmt = $this->createMock(PDOStatement::class);
        $this->conn->method('prepare')->willReturn($stmt);

        // Mock the execute method
        $stmt->method('execute')->willReturn(true);

        // Mock the rowCount method to return more than 0
        $stmt->method('rowCount')->willReturn(1);

        // Mock the fetch method to return a sample product
        $stmt->method('fetch')->willReturn([
            'id' => 1,
            'name' => 'Vanilla Ice Cream',
            'price' => 5.99,
            'image' => 'vanilla.jpg'
        ]);

        // Include the category.php script
        ob_start();
        include 'path/to/category.php';
        $output = ob_get_clean();

        // Assert that the page displays the product
        $this->assertStringContainsString('Vanilla Ice Cream', $output);
        $this->assertStringContainsString('$5.99', $output);
        $this->assertStringContainsString('vanilla.jpg', $output);
    }

    public function testCategoryPageHandlesNoProducts()
    {
        // Simulate a category being passed in the GET request
        $_GET['category'] = 'Nonexistent Category';

        // Mock the prepare method to return a PDOStatement mock
        $stmt = $this->createMock(PDOStatement::class);
        $this->conn->method('prepare')->willReturn($stmt);

        // Mock the execute method
        $stmt->method('execute')->willReturn(true);

        // Mock the rowCount method to return 0
        $stmt->method('rowCount')->willReturn(0);

        // Include the category.php script
        ob_start();
        include 'path/to/category.php';
        $output = ob_get_clean();

        // Assert that the page handles no products
        $this->assertStringContainsString('<p class="empty">no products added yet!</p>', $output);
    }
}
?>
