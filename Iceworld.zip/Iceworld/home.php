<?php

include 'components/connect.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

include 'components/add_cart.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Ice World Home Page</title>

   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/styles1.css">
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="css/style2.css">

</head>
<body>

<?php include 'components/user_header.php'; ?>
<!---Section main--->
<section class="main-section">
   <h1 class="main-h">🍦 𝐼𝒞𝐸 𝒲𝒪𝑅𝐿𝒟</h1>
   <h2 class="main-h2">Welcome To the Magic World!</h2>
   <p class="main-p">You can taste Your dream Ice Cream</p>
</section>


<!---Image slider home page--->
    

<div class="slider">
    <div class="list">
        <div class="item active">
            <img src="./image/image2.jfif" alt="">
            <div class="content">
                <div class="title" style="color:var(--black);"></div>
                <div class="type" style="color:yellow; text-align:left;">🍦 𝐼𝒞𝐸 𝒲𝒪𝑅𝐿𝒟</div>
                <div class="type" style="color:orange;">Welcome!</div>
                <br>
            </div>
        </div>
        <div class="item">
            <img src="./image/service2.jpg" alt="Customer Service Image">
            <div class="content">
               <br>
                <div class="title" style="color:var(--cream); text-align:left;">🍦 𝐼𝒞𝐸 𝒲𝒪𝑅𝐿𝒟</div>
                <div class="type" style="color:orange;">Customer Service</div>
            </div>
        </div>
        <div class="item">
            <img src="./image/delivery2.jpg" alt="Delivery Service Image">
            <div class="content">
               <br>
                <div class="title" style="color:var(--cream); text-align:left;">🍦 𝐼𝒞𝐸 𝒲𝒪𝑅𝐿𝒟</div>
                <div class="type" style="color:orange; ">Delivery Service</div>
            </div>
        </div>
        <div class="item">
            <img src="./image/types1.jpg" alt="">
            <div class="content">
                <div class="title" style="color:var(--cream); text-align:left;">🍦 𝐼𝒞𝐸 𝒲𝒪𝑅𝐿𝒟</div>
                <div class="type" style="color:orange;">Ice Cream Types</div>
            </div>
        </div>
    </div>

    <div class="thumbnail">
        <div class="item active">
            <img src="./image/image2.jfif" alt="Wecome Image">
        </div>
        <div class="item">
            <img src="./image/service2.jpg" alt="Customer Service Image">
        </div>
        <div class="item">
            <img src="./image/delivery2.jpg" alt="Delivery Service">
        </div>
        <div class="item">
            <img src="./image/types1.jpg" alt="Ice Cream Types">
        </div>
    </div>

    <div class="nextPrevArrows">
        <button class="prev"> < </button>
        <button class="next"> > </button>
    </div>
</div>

<script>
    const items = document.querySelectorAll('.slider .list .item');
    const thumbnails = document.querySelectorAll('.slider .thumbnail .item');
    const prevBtn = document.querySelector('.prev');
    const nextBtn = document.querySelector('.next');
    let currentIndex = 0;

    function showSlide(index) {
        items.forEach((item, i) => {
            item.classList.remove('active', 'prev', 'inactive');
            thumbnails[i].classList.remove('active');
            if (i === index) {
                item.classList.add('active');
                thumbnails[i].classList.add('active');
            } else if (i === (index - 1 + items.length) % items.length) {
                item.classList.add('prev');
            } else {
                item.classList.add('inactive');
            }
        });
    }

    function nextSlide() {
        currentIndex = (currentIndex + 1) % items.length;
        showSlide(currentIndex);
    }

    function prevSlide() {
        currentIndex = (currentIndex - 1 + items.length) % items.length;
        showSlide(currentIndex);
    }

    nextBtn.addEventListener('click', nextSlide);
    prevBtn.addEventListener('click', prevSlide);

    let autoSlideInterval = setInterval(nextSlide, 4000); // Change slide every 3 seconds

    document.querySelector('.slider').addEventListener('mouseenter', () => {
        clearInterval(autoSlideInterval);
    });

    document.querySelector('.slider').addEventListener('mouseleave', () => {
        autoSlideInterval = setInterval(nextSlide, 4000);
    });
</script>


<section class="products">

   <h1 class="title">Latest Ice Creem Products</h1>

   <div class="box-container">

      <?php
         $select_products = $conn->prepare("SELECT * FROM `products` LIMIT 6");
         $select_products->execute();
         if($select_products->rowCount() > 0){
            while($fetch_products = $select_products->fetch(PDO::FETCH_ASSOC)){
      ?>
      <form action="" method="post" class="box">
         <input type="hidden" name="pid" value="<?= $fetch_products['id']; ?>">
         <input type="hidden" name="name" value="<?= $fetch_products['name']; ?>">
         <input type="hidden" name="price" value="<?= $fetch_products['price']; ?>">
         <input type="hidden" name="image" value="<?= $fetch_products['image']; ?>">
         <a href="quick_view.php?pid=<?= $fetch_products['id']; ?>" class="fas fa-eye"></a>
         <button type="submit" class="fas fa-shopping-cart" name="add_to_cart"></button>
         <img src="uploaded_img/<?= $fetch_products['image']; ?>" alt="">
         <a href="category.php?category=<?= $fetch_products['category']; ?>" class="cat"><?= $fetch_products['category']; ?></a>
         <div class="name"><?= $fetch_products['name']; ?></div>
         <div class="flex">
            <div class="price"><span>$.</span><?= $fetch_products['price']; ?></div>
            <input type="number" name="qty" class="qty" min="1" max="99" value="1" maxlength="2">
         </div>
      </form>
      <?php
            }
         }else{
            echo '<p class="empty">no products added yet!</p>';
         }
      ?>

   </div>

   <div class="more-btn">
      <a href="menu.html" class="btn">veiw all</a>
   </div>

</section>



<section class="category">

   <h1 class="title">Ice Cream categories</h1>

   <div class="box-container">

      <a href="category.php?category=vanilla" class="box">
         <img src="image/vanilla.jfif" alt="">
         <h3>Vanilla</h3>
      </a>

      <a href="category.php?category=chocolate" class="box">
         <img src="image/chocolate.jfif" alt="">
         <h3>Chocolate</h3>
      </a>

      <a href="category.php?category=strawberry" class="box">
         <img src="image/strawberry.jpg" alt="Strawberry Ice Cream"  style="height:100px;">
         <h3>Strawberry</h3>
      </a>

      <a href="category.php?category=other" class="box">
         <img src="image/mintchocolate.jfif" alt="">
         <h3>Other Flavours</h3>
      </a>

   </div>

</section>

<section class="hero">

   <div class="swiper hero-slider">

      <div class="swiper-wrapper">

         <div class="swiper-slide slide">
            <div class="content">
               <span>Feel the Magic</span>
               <h3>Tasty Ice cream</h3>
               <a href="menu.php" class="btn">see menu</a>
            </div>
            <div class="image">
               <img src="image/image5.jfif" alt="">
            </div>
         </div>

         <div class="swiper-slide slide">
            <div class="content">
               <span>Visit Us</span>
               <h3>Visit Our Shop</h3>
               <a href="menu.php" class="btn">see menu</a>
            </div>
            <div class="image">
               <img src="image/shop1.jpg" alt="">
            </div>
         </div>

         <div class="swiper-slide slide">
            <div class="content">
               <span>Order Online</span>
               <h3>Fast Delivery Service</h3>
               <a href="menu.php" class="btn">see menu</a>
            </div>
            <div class="image">
               <img src="image/delivery.jfif" alt="">
            </div>
         </div>

      </div>

      <div class="swiper-pagination"></div>

   </div>

</section>





















<?php include 'components/footer.php'; ?>


<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

<script>

var swiper = new Swiper(".hero-slider", {
   loop:true,
   grabCursor: true,
   effect: "flip",
   pagination: {
      el: ".swiper-pagination",
      clickable:true,
   },
});

</script>
<script src="js/app.js"></script>

</body>
</html>