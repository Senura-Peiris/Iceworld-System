<?php

use PHPUnit\Framework\TestCase;
use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;

class OrdersTest extends TestCase
{
    private $client;

    protected function setUp(): void
    {
        $this->client = new Client(['base_uri' => 'http://localhost/Iceworld/']);
    }

    public function testOrdersPageAccessWithoutLogin()
    {
        $response = $this->client->get('orders.php', ['http_errors' => false]);
        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('please login to see your orders', (string) $response->getBody());
    }

    public function testOrdersPageAccessWithLoginButNoOrders()
    {
        $cookieJar = new CookieJar();
        $response = $this->client->post('login.php', [
            'form_params' => [
                'email' => 'user@example.com',
                'pass' => 'password',
                'submit' => 'login now'
            ],
            'cookies' => $cookieJar
        ]);

        $response = $this->client->get('orders.php', [
            'cookies' => $cookieJar,
            'http_errors' => false
        ]);

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('no orders placed yet!', (string) $response->getBody());
    }

    public function testOrdersPageAccessWithLoginAndExistingOrders()
    {
        // Assuming user has existing orders in the database
        $cookieJar = new CookieJar();
        $response = $this->client->post('login.php', [
            'form_params' => [
                'email' => 'user@example.com',
                'pass' => 'password',
                'submit' => 'login now'
            ],
            'cookies' => $cookieJar
        ]);

        $response = $this->client->get('orders.php', [
            'cookies' => $cookieJar,
            'http_errors' => false
        ]);

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertStringContainsString('placed on :', (string) $response->getBody());
        $this->assertStringContainsString('payment method :', (string) $response->getBody());
    }
}
